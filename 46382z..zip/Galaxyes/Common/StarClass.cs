﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Galaxies.Common
{
    public enum StarClass
    {
        M,
        K,
        G,
        F,
        A,
        B,
        O,
        Unknown
    }
}
