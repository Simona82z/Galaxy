﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Galaxies.Models
{
    public abstract class BaseModel
    {
        public string Name { get; set; }
    }
}
